#!/usr/bin/env python3
"""Deterministic literature deduplication. Domain-agnostic."""
import argparse, json, re, difflib

def norm(s):
    s=(s or "").lower()
    s=re.sub(r"[^a-z0-9\u4e00-\u9fff]+"," ",s)
    return re.sub(r"\s+"," ",s).strip()

def key_title(p):
    return norm(p.get("title",""))

def merge(a,b):
    out=dict(a)
    for k,v in b.items():
        if (out.get(k) in (None,"",[])) and v not in (None,"",[]):
            out[k]=v
    out["source_records"]=list(dict.fromkeys(
        (out.get("source_records") or []) + (b.get("source_records") or [])
    ))
    return out

def deduplicate(papers, threshold=0.96):
    by_id={}
    result=[]
    title_keys=[]

    for p in papers:
        ids=[]
        for k in ("doi","article_id","arxiv_id"):
            v=norm(p.get(k,""))
            if v: ids.append((k,v))
        found=None
        for k,v in ids:
            if (k,v) in by_id:
                found=by_id[(k,v)]
                break
        if found is None:
            t=key_title(p)
            if t:
                for old_t, idx in title_keys:
                    ratio=difflib.SequenceMatcher(None,t,old_t).ratio()
                    if ratio >= threshold:
                        # Prefer same/near year or same first author.
                        oy=result[idx].get("year")
                        py=p.get("year")
                        oa=(result[idx].get("authors") or [""])[0] if result[idx].get("authors") else ""
                        pa=(p.get("authors") or [""])[0] if p.get("authors") else ""
                        if (oy and py and oy==py) or norm(oa)==norm(pa):
                            found=idx
                            break
        if found is None:
            idx=len(result)
            result.append(dict(p))
            t=key_title(p)
            if t: title_keys.append((t,idx))
            for k,v in ids: by_id[(k,v)]=idx
        else:
            result[found]=merge(result[found],p)
            for k,v in ids: by_id[(k,v)]=found

    return result

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("-o","--output")
    args=ap.parse_args()
    with open(args.input,encoding="utf-8") as f:
        data=json.load(f)
    if isinstance(data,dict):
        papers=data.get("literature_set",[])
        out=dict(data)
        out["literature_set"]=deduplicate(papers)
    else:
        out=deduplicate(data)
    payload=json.dumps(out,ensure_ascii=False,indent=2)
    if args.output:
        with open(args.output,"w",encoding="utf-8") as f:f.write(payload)
    else: print(payload)

if __name__=="__main__": main()
