#!/usr/bin/env python3
"""
Deterministic coverage analysis for Adaptive Literature Retrieval Skill.

Input: a JSON state file containing concept_schema and literature_set.
Output: JSON state with coverage, gaps, and marginal-gain statistics.

No domain-specific vocabulary is embedded in this script.
"""
import argparse, json, re, sys
from collections import defaultdict

def norm(s):
    s = (s or "").lower()
    s = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()

def paper_blob(p):
    fields = [
        p.get("title",""), p.get("abstract_original",""),
        p.get("abstract_chinese",""), p.get("venue","")
    ]
    fields += p.get("authors",[]) if isinstance(p.get("authors",[]), list) else []
    return norm(" ".join(map(str, fields)))

def concept_records(schema):
    out = []
    for dim in ("methods","tasks","applications","related_problems"):
        vals = schema.get(dim, []) if isinstance(schema, dict) else []
        for i, v in enumerate(vals):
            if isinstance(v, str):
                out.append({
                    "term": v, "dimension": dim, "weight": 0.8,
                    "source": "unknown", "confidence": "unknown",
                    "evidence_paper_ids": []
                })
            elif isinstance(v, dict):
                term = v.get("term") or v.get("normalized_term")
                if term:
                    x = dict(v)
                    x.setdefault("dimension", dim)
                    x.setdefault("weight", 0.8)
                    x.setdefault("evidence_paper_ids", [])
                    out.append(x)
    return out

def paper_matches(term, paper):
    t = norm(term)
    if not t:
        return False
    blob = paper_blob(paper)
    # Exact normalized phrase first.
    if t in blob:
        return True
    # For multiword terms, require all meaningful tokens.
    toks = [x for x in t.split() if len(x) > 1]
    return len(toks) >= 2 and all(x in blob for x in toks)

def analyze(state):
    papers = state.get("literature_set", []) or []
    verified = [
        p for p in papers
        if str(p.get("verification_status","")).lower()
        in {"verified","verified_high","verified high"}
    ]
    # If verification status is absent, do not silently treat it as verified.
    relevant = [
        p for p in verified
        if float(p.get("relevance_score") or 0) >= 0.5
    ]

    concepts = concept_records(state.get("concept_schema", {}))
    dim_stats = defaultdict(lambda: {"weighted_total":0.0, "weighted_covered":0.0, "concepts":[]})

    for c in concepts:
        term = c["term"]
        weight = float(c.get("weight", 0.8))
        evidence_ids = set(map(str, c.get("evidence_paper_ids") or []))
        matched_ids = []
        for p in relevant:
            pid = str(p.get("paper_id") or p.get("doi") or p.get("title") or "")
            if (pid and pid in evidence_ids) or paper_matches(term, p):
                matched_ids.append(pid)

        # Adequate evidence: at least 2 relevant papers, or 1 for a high-confidence
        # concept with explicit evidence. This is an operational search metric.
        confidence = str(c.get("confidence","")).lower()
        covered = len(matched_ids) >= 2 or (confidence == "high" and len(matched_ids) >= 1)

        ds = dim_stats[c.get("dimension","other")]
        ds["weighted_total"] += weight
        if covered:
            ds["weighted_covered"] += weight

        ds["concepts"].append({
            "term": term,
            "weight": weight,
            "matched_papers": len(matched_ids),
            "matched_paper_ids": matched_ids[:100],
            "status": "covered" if covered else "gap",
            "confidence": c.get("confidence"),
            "source": c.get("source")
        })

    coverage = {}
    gaps = []
    for dim, ds in dim_stats.items():
        pct = (ds["weighted_covered"]/ds["weighted_total"]*100) if ds["weighted_total"] else 0.0
        coverage[dim] = {
            "percentage": round(pct,2),
            "covered_weight": round(ds["weighted_covered"],4),
            "total_weight": round(ds["weighted_total"],4),
            "concept_count": len(ds["concepts"])
        }
        for c in ds["concepts"]:
            if c["status"] == "gap":
                deficit = float(c["weight"])
                priority = round(deficit * (1.0 if c.get("confidence")=="high" else 0.8), 4)
                gaps.append({
                    "type": f"{dim[:-1] if dim.endswith('s') else dim}_gap",
                    "dimension": dim,
                    "concept": c["term"],
                    "priority": priority,
                    "matched_papers": c["matched_papers"],
                    "recommended_action": "keyword_search"
                })

    # Venue and temporal coverage are computed from requested sets if supplied.
    venue_targets = state.get("venue_set", []) or []
    if venue_targets:
        names = []
        for v in venue_targets:
            names.append(norm(v.get("name","") if isinstance(v,dict) else v))
        names = [x for x in names if x]
        covered = sum(1 for v in names if any(v in norm(p.get("venue","")) for p in verified))
        coverage["venues"] = {
            "percentage": round(100*covered/len(names),2) if names else 0.0,
            "covered": covered, "total": len(names)
        }

    time_range = state.get("time_range", {}) or {}
    years = []
    if isinstance(time_range, dict):
        start, end = time_range.get("start"), time_range.get("end")
        if isinstance(start,int) and isinstance(end,int) and start <= end:
            years = list(range(start,end+1))
    if years:
        present = {int(p["year"]) for p in verified if str(p.get("year","")).isdigit()}
        covered = sum(1 for y in years if y in present)
        coverage["time"] = {
            "percentage": round(100*covered/len(years),2),
            "covered_years": covered, "total_years": len(years)
        }

    # Citation expansion coverage is evidence-based rather than guessed.
    expanded = state.get("citation_expansion", {}) or {}
    if expanded:
        coverage["citation"] = {
            "percentage": float(expanded.get("coverage_percentage",0)),
            "backward_done": bool(expanded.get("backward_done",False)),
            "forward_done": bool(expanded.get("forward_done",False)),
            "similar_done": bool(expanded.get("similar_done",False))
        }

    # Marginal gain from retrieval log.
    logs = state.get("retrieval_log", []) or []
    if logs:
        gains = [int(x.get("new_unique",0) or 0) for x in logs[-5:]]
        relevant_gains = [int(x.get("relevant",0) or 0) for x in logs[-5:]]
        dup_rates = []
        for x in logs[-5:]:
            r = int(x.get("retrieved",0) or 0)
            d = int(x.get("duplicates",0) or 0)
            if r: dup_rates.append(d/r)
        coverage["retrieval_yield"] = {
            "recent_new_unique": gains,
            "recent_relevant": relevant_gains,
            "mean_recent_relevant": round(sum(relevant_gains)/len(relevant_gains),3) if relevant_gains else 0,
            "mean_recent_duplicate_rate": round(sum(dup_rates)/len(dup_rates),3) if dup_rates else 0
        }

    gaps.sort(key=lambda x: (-x["priority"], x["concept"]))
    state["coverage"] = coverage
    state["gaps"] = gaps
    return state

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("-o","--output")
    args = ap.parse_args()
    with open(args.input, encoding="utf-8") as f:
        state = json.load(f)
    out = analyze(state)
    payload = json.dumps(out, ensure_ascii=False, indent=2)
    if args.output:
        with open(args.output,"w",encoding="utf-8") as f: f.write(payload)
    else:
        print(payload)

if __name__ == "__main__":
    main()
