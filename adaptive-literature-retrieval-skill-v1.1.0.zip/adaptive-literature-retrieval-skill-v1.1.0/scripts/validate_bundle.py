#!/usr/bin/env python3
"""Validate the skill bundle structure and portability constraints."""
import argparse, re, sys
from pathlib import Path

REQUIRED = [
    "SKILL.md",
    "README.md",
    "CHANGELOG.md",
    "references/dynamic_concept_schema.md",
    "references/adaptive_retrieval_policy.md",
    "references/verification_policy.md",
    "references/venue_discovery_policy.md",
    "references/excel_output_schema.md",
    "references/platform_compatibility.md",
    "schemas/research_state.schema.json",
    "schemas/paper.schema.json",
    "schemas/retrieval_log.schema.json",
    "scripts/coverage_analyzer.py",
    "scripts/deduplicate.py",
    "scripts/export_excel.py",
    "scripts/validate_bundle.py",
    "scripts/requirements.txt",
    "examples/demo_state.json",
]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("root")
    args=ap.parse_args()
    root=Path(args.root)
    errors=[]
    for rel in REQUIRED:
        if not (root/rel).is_file():
            errors.append("missing: "+rel)

    skill=(root/"SKILL.md").read_text(encoding="utf-8") if (root/"SKILL.md").exists() else ""
    if not skill.startswith("---"):
        errors.append("SKILL.md missing YAML frontmatter")
    if "name:" not in skill or "description:" not in skill:
        errors.append("SKILL.md frontmatter missing name/description")

    # Detect obvious hard-coded domain lookup structures without embedding
    # any domain vocabulary in this validator.
    for p in root.joinpath("scripts").glob("*.py"):
        txt=p.read_text(encoding="utf-8",errors="ignore")
        if re.search(r"(METHOD|TASK|APP|DOMAIN|VENUE)_TERMS\s*=", txt):
            errors.append(f"possible fixed vocabulary table in {p.name}")

    # Core scripts should not depend on network libraries.
    for name in ("coverage_analyzer.py","deduplicate.py","export_excel.py"):
        p=root/"scripts"/name
        if p.exists():
            txt=p.read_text(encoding="utf-8",errors="ignore")
            if re.search(r"^\s*(import|from)\s+(requests|httpx|aiohttp|urllib3)\b", txt, re.M):
                errors.append(f"unexpected network dependency in {name}")

    if errors:
        print("\n".join(errors), file=sys.stderr)
        sys.exit(1)
    print("VALID: bundle structure and domain-agnostic portability checks passed.")

if __name__=="__main__": main()
