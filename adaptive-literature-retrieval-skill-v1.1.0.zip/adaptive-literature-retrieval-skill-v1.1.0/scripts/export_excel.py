#!/usr/bin/env python3
"""Generate the user-facing Excel workbook for Adaptive Literature Retrieval."""
import argparse, json, os, re, sys
from pathlib import Path

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment
    from openpyxl.utils import get_column_letter
except Exception as e:
    print("openpyxl is required for Excel export:", e, file=sys.stderr)
    sys.exit(2)

FINAL_HEADERS = ["论文标题","发表年份以及发表的刊物/会议","作者机构","论文摘要的中文翻译","下载链接"]

def s(v):
    if v is None: return ""
    if isinstance(v,(list,tuple)): return "; ".join(map(str,v))
    if isinstance(v,dict): return json.dumps(v,ensure_ascii=False)
    return str(v)

def style_sheet(ws, widths=None):
    ws.freeze_panes="A2"
    for cell in ws[1]:
        cell.font=Font(bold=True)
        cell.alignment=Alignment(vertical="top", wrap_text=True)
    for row in ws.iter_rows():
        for cell in row:
            cell.alignment=Alignment(vertical="top", wrap_text=True)
    if widths:
        for i,w in enumerate(widths,1):
            ws.column_dimensions[get_column_letter(i)].width=w

def export(state, out_path):
    wb=Workbook()
    ws=wb.active
    ws.title="Final Literature"
    ws.append(FINAL_HEADERS)
    for p in state.get("literature_set",[]):
        status=str(p.get("verification_status","")).lower()
        rel=float(p.get("relevance_score") or 0)
        if status not in {"verified","verified_high","verified high"} or rel < 0.5:
            continue
        venue=s(p.get("venue"))
        year=s(p.get("year"))
        ws.append([
            s(p.get("title")),
            f"{year} — {venue}".strip(" —"),
            s(p.get("affiliations")),
            s(p.get("abstract_chinese")),
            s(p.get("pdf_url") or p.get("paper_url"))
        ])
    style_sheet(ws,[48,30,46,100,55])

    ws=wb.create_sheet("Retrieval Log")
    headers=["Round","Action","Reason","Query","Source","Retrieved","New Unique","Relevant","Duplicates","Verification Failures","Coverage Before","Coverage After","Marginal Gain","Decision"]
    ws.append(headers)
    for r in state.get("retrieval_log",[]):
        ws.append([
            r.get("round"),r.get("action"),r.get("reason"),
            s(r.get("queries")),s(r.get("sources")),
            r.get("retrieved",0),r.get("new_unique",0),r.get("relevant",0),
            r.get("duplicates",0),r.get("verification_failures",0),
            s(r.get("coverage_before")),s(r.get("coverage_after")),
            s(r.get("marginal_gain")),r.get("decision")
        ])
    style_sheet(ws,[10,22,55,65,28,12,12,12,12,18,45,45,28,12])

    ws=wb.create_sheet("Coverage Analysis")
    headers=["Dimension","Concept","Weight","Verified Relevant Papers","Coverage Status","Evidence","Gap","Recommended Next Action"]
    ws.append(headers)
    cov=state.get("coverage",{})
    for dim, block in cov.items():
        if not isinstance(block,dict) or "percentage" not in block: continue
        # Add aggregate row; concept-level detail follows from dynamic schema.
        ws.append([dim,"[aggregate]", "", "", f"{block.get('percentage','')}%", "", "", ""])
    for g in state.get("gaps",[]):
        ws.append([
            g.get("dimension"),g.get("concept"),g.get("priority"),
            g.get("matched_papers",0),"gap","",g.get("type"),
            g.get("recommended_action","keyword_search")
        ])
    style_sheet(ws,[24,45,12,24,22,60,24,28])

    ws=wb.create_sheet("Verification")
    headers=["Title","DOI/Identifier","Bibliographic Source","Publisher Source","Metadata Status","Abstract Status","Link Status","Verification Status"]
    ws.append(headers)
    for p in state.get("literature_set",[]):
        ws.append([
            s(p.get("title")),
            s(p.get("doi") or p.get("article_id") or p.get("arxiv_id")),
            s(p.get("source_records")),
            s(p.get("paper_url")),
            s(p.get("metadata_status") or p.get("verification_status")),
            "available" if p.get("abstract_original") else "unavailable",
            "verified" if p.get("pdf_url") or p.get("paper_url") else "unavailable",
            s(p.get("verification_status"))
        ])
    style_sheet(ws,[55,35,55,55,22,18,18,22])

    ws=wb.create_sheet("Excluded Papers")
    headers=["Title","Year","Venue","Exclusion Reason","Verification Status","Notes"]
    ws.append(headers)
    for p in state.get("excluded_papers",[]):
        ws.append([s(p.get("title")),s(p.get("year")),s(p.get("venue")),s(p.get("exclusion_reason")),s(p.get("verification_status")),s(p.get("notes"))])
    style_sheet(ws,[55,12,35,40,22,70])

    ws=wb.create_sheet("Search Plan")
    headers=["Dimension","Concept","Query","Source","Priority","Round","Status"]
    ws.append(headers)
    for q in state.get("search_plan",[]):
        ws.append([s(q.get("dimension")),s(q.get("concept")),s(q.get("query")),s(q.get("source")),s(q.get("priority")),s(q.get("round")),s(q.get("status"))])
    style_sheet(ws,[24,40,75,30,14,10,18])

    ws=wb.create_sheet("Run Summary")
    summary=state.get("run_summary",{})
    if not summary:
        summary={
            "topic":state.get("research_topic"),
            "time_range":state.get("time_range"),
            "venue_scope":state.get("venue_set"),
            "retrieval_rounds":len(state.get("retrieval_log",[])),
            "final_verified_relevant":sum(
                1 for p in state.get("literature_set",[])
                if str(p.get("verification_status","")).lower() in {"verified","verified_high","verified high"}
                and float(p.get("relevance_score") or 0)>=0.5
            ),
            "stopping_reason":state.get("stopping_reason","")
        }
    ws.append(["Metric","Value"])
    for k,v in summary.items():
        ws.append([k,s(v)])
    style_sheet(ws,[32,110])

    Path(out_path).parent.mkdir(parents=True,exist_ok=True)
    wb.save(out_path)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("-o","--output",required=True)
    args=ap.parse_args()
    with open(args.input,encoding="utf-8") as f: state=json.load(f)
    export(state,args.output)
    print(args.output)

if __name__=="__main__": main()
