# Dynamic Research Concept Schema

The research schema is created anew for every user request.

## Dimensions

### Methods
Technologies, algorithms, models, frameworks, or methodological paradigms used to address the research problem.

### Tasks
Concrete problems or computational/research tasks being solved.

### Applications
Objects, domains, environments, systems, or scenarios where the methods/tasks are applied.

### Related Problems
Constraints, objectives, properties, failure modes, evaluation concerns, or adjacent problems that define the research boundary.

## Rules

1. Never assume a fixed domain.
2. Generate concepts from the user topic first.
3. Add concepts discovered in verified relevant papers only when evidence is sufficient.
4. Keep source and confidence for each concept.
5. Do not use a giant universal synonym dictionary.
6. Prefer a small, high-value concept set over uncontrolled expansion.

## Concept record

```json
{
  "term": "example",
  "normalized_term": "example",
  "dimension": "methods",
  "source": "user|model_expansion|literature_discovered",
  "confidence": "high|medium|low",
  "weight": 0.8,
  "evidence_paper_ids": []
}
```
