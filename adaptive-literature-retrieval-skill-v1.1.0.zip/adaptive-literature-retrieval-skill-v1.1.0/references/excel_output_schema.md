# Excel Output Schema

## Final Literature

Exactly:

1. 论文标题
2. 发表年份以及发表的刊物/会议
3. 作者机构
4. 论文摘要的中文翻译
5. 下载链接

## Additional sheets

- Retrieval Log
- Coverage Analysis
- Verification
- Excluded Papers
- Search Plan
- Run Summary

The final sheet is the user-facing literature table. The other sheets make the retrieval process auditable.
