# Platform Compatibility

## ChatGPT

The current OpenAI Skills documentation describes skills as a folder bundle centered on a `SKILL.md` file, with optional scripts/references/assets, and supports uploading a ZIP containing one top-level skill folder. This skill intentionally uses only standard skill metadata in `SKILL.md` and avoids platform-specific tool names.

Recommended host capabilities:
- web search/browser access for live literature retrieval;
- file/Excel creation for workbook output;
- Python/shell execution if deterministic helper scripts are enabled.

## Tencent WorkBuddy / CodeBuddy

WorkBuddy/CodeBuddy documents the same core pattern: a self-contained skill directory with `SKILL.md` plus optional `scripts/`, `references/`, and `assets/`. The skill therefore keeps all platform-neutral workflow instructions in `SKILL.md`.

If the host does not expose Python execution, follow the same workflow with native spreadsheet/file tools and treat the bundled scripts as optional deterministic helpers.

## Portability rule

The skill never assumes a specific provider tool name. The host's actual search/browser/file tools should be mapped to the generic actions described in `SKILL.md`.
