# Adaptive Retrieval Policy

The search controller maintains a state and chooses the next action from the current evidence.

## State

- literature set
- dynamic concept schema
- venue set
- query history
- retrieval log
- coverage
- gaps
- marginal gains

## Actions

- keyword search
- semantic search
- venue search
- time-specific search
- author search
- backward citation
- forward citation
- similar paper
- terminology expansion

## Decision logic

Prioritize actions that address the largest high-confidence coverage gap and have high expected information gain.

Example:

```text
method coverage: high
task coverage: high
application coverage: medium
related-problem coverage: low
citation coverage: low

next action:
    related-problem keyword search
    + forward citation expansion
```

## Saturation

A stop decision should require evidence from several signals:

- requested venue groups searched;
- requested time range searched;
- no high-priority concept gap;
- citation expansion performed where useful;
- recent rounds have low new relevant yield;
- duplicate rate is high.

Never use a fixed number of rounds as the only stopping rule.
