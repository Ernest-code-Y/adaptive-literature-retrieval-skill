# Verification Policy

A paper is final only if its bibliographic identity can be verified.

## Required fields

- title
- authors
- year
- venue
- persistent identifier where available
- authoritative or trusted bibliographic evidence

## Confidence

`verified_high`
- authoritative publisher/official record and an independent bibliographic record agree.

`verified`
- one strong authoritative/trusted record is sufficient.

`unverified`
- identity is ambiguous or evidence is insufficient.

## Link policy

Use, in order:

1. verified open-access PDF;
2. verified legal preprint/full text;
3. official publisher page.

Never invent a URL and never use unauthorized copies.

## Abstract policy

Translate only an abstract that has been retrieved from a source. If unavailable, say so.
