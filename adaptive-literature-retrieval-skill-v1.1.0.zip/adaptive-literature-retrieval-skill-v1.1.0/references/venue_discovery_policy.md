# Dynamic Venue Discovery Policy

Venue selection depends on the current research topic.

## Required hierarchy

1. Relevant Nature portfolio journals.
2. Relevant Science family journals.
3. Current CCF A venues when applicable.
4. Field-leading journals/conferences verified through authoritative or reliable sources.
5. Other relevant venues needed for recall.

## Important distinctions

- Do not treat every Nature/Science-branded venue as relevant.
- Do not call a venue CCF A without checking the requested/current classification.
- Do not call a venue a field-leading venue based only on model memory.
- Keep the evidence/source for venue classification.

Venue discovery may be repeated after literature discovery reveals a missing research community or venue.
