# Adaptive Literature Retrieval Skill v1.1.0

A domain-agnostic, coverage-aware, evidence-grounded literature retrieval skill designed for portable use in ChatGPT Skills and Tencent WorkBuddy/CodeBuddy-style Skill environments.

## What changed from v1.0

- Removed aerospace/control hard-coded deterministic vocabulary.
- Methods, Tasks, Applications, and Related Problems are dynamically derived from each user's research topic.
- Dynamic concepts can be updated from verified literature during retrieval.
- Venue discovery is topic-dependent rather than fixed to a domain.
- Coverage analysis uses the current research schema rather than a fixed domain checklist.
- Deterministic scripts operate on JSON state and contain no domain-specific vocabulary.
- Added stronger verification, retrieval logs, adaptive action selection, and saturation checks.
- Added a seven-sheet Excel specification.

## Portable design

The core workflow is in `SKILL.md`. It does not require a specific web-search provider or a platform-specific tool name.

- In ChatGPT, upload the ZIP through the Skills interface when available.
- In WorkBuddy/CodeBuddy, install/import the skill into the supported user/project skill directory.

The host should provide live search/browser capabilities for actual literature retrieval. The bundled Python scripts are deterministic helpers for state analysis, deduplication, validation, and Excel generation.

## Directory

```text
adaptive-literature-retrieval-skill-v1.1.0/
├── SKILL.md
├── README.md
├── references/
│   ├── dynamic_concept_schema.md
│   ├── adaptive_retrieval_policy.md
│   ├── verification_policy.md
│   ├── venue_discovery_policy.md
│   └── excel_output_schema.md
├── schemas/
│   ├── research_state.schema.json
│   ├── paper.schema.json
│   └── retrieval_log.schema.json
├── scripts/
│   ├── coverage_analyzer.py
│   ├── deduplicate.py
│   ├── export_excel.py
│   └── validate_bundle.py
└── examples/
    └── demo_state.json
```
