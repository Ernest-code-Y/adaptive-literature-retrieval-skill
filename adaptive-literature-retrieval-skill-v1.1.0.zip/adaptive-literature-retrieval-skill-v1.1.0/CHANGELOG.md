# Changelog

## v1.1.0

- Removed fixed aerospace/control deterministic vocabulary.
- Added dynamic Methods / Tasks / Applications / Related Problems analysis.
- Added evidence-based concept updates during retrieval.
- Added dynamic venue discovery.
- Added coverage-aware adaptive retrieval loop.
- Added explicit retrieval-log requirements.
- Added deterministic, domain-agnostic deduplication and coverage helpers.
- Added verification/link/abstract quality gates.
- Added seven-sheet Excel output specification.
- Added ChatGPT and WorkBuddy/CodeBuddy portability guidance.
